<template>
  <div class="min-h-screen bg-background">
    <!-- Header -->
    <header class="bg-card border-b border-border sticky top-0 z-40">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="flex justify-between items-start md:items-center gap-4">
          <div>
            <h1 class="text-3xl font-bold">Dashboard</h1>
            <p class="text-muted-foreground mt-1">
              Welcome back, {{ authUser?.name }}
            </p>
          </div>

          <!-- Desktop Buttons -->
          <div class="hidden md:flex gap-3">
            <RouterLink
              to="/tickets/create"
              class="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition"
            >
              Manage Tickets
            </RouterLink>
            <button
              @click="handleLogout"
              class="px-4 py-2 border border-border rounded-lg hover:bg-secondary transition"
            >
              Logout
            </button>
          </div>

          <!-- Mobile Menu Button -->
          <button
            class="md:hidden"
            @click="isMenuOpen = !isMenuOpen"
            aria-label="Toggle menu"
          >
            <Menu class="w-6 h-6" />
          </button>
        </div>

        <!-- Mobile Menu -->
        <div v-if="isMenuOpen" class="md:hidden mt-4 space-y-2">
          <RouterLink
            to="/tickets/create"
            class="block px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition text-center"
          >
            Manage Tickets
          </RouterLink>
          <button
            @click="handleLogout"
            class="w-full px-4 py-2 border border-border rounded-lg hover:bg-secondary transition"
          >
            Logout
          </button>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <!-- Stats Grid -->
      <div class="grid md:grid-cols-4 gap-6 mb-12">
        <div
          v-for="stat in stats"
          :key="stat.label"
          class="bg-card rounded-lg border border-border p-6"
        >
          <p class="text-muted-foreground text-sm mb-2">{{ stat.label }}</p>
          <p :class="['text-3xl font-bold', stat.color]">{{ stat.value }}</p>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="bg-card rounded-lg border border-border p-6">
        <h2 class="text-xl font-semibold mb-4">Quick Actions</h2>
        <div class="flex flex-col sm:flex-row gap-4">
          <RouterLink
            to="/tickets/create"
            class="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition text-center"
          >
            Create New Ticket
          </RouterLink>
          <RouterLink
            to="/tickets"
            class="px-6 py-3 border border-primary text-primary rounded-lg hover:bg-primary/10 transition text-center"
          >
            View All Tickets
          </RouterLink>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <footer class="bg-secondary/50 border-t border-border py-8 px-4 sm:px-6 lg:px-8 mt-12">
      <div class="max-w-7xl mx-auto text-center text-muted-foreground">
        &copy; 2025 TicketFlow. All rights reserved.
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { Menu } from 'lucide-vue-next'
import { authUser, logout } from '@/lib/auth'
import { getTicketStats } from '@/lib/ticket-store'

const router = useRouter()
const isMenuOpen = ref(false)
const stats = ref([
  { label: 'Total Tickets', value: 0, color: 'text-primary' },
  { label: 'Open', value: 0, color: 'text-status-open' },
  { label: 'In Progress', value: 0, color: 'text-status-in-progress' },
  { label: 'Closed', value: 0, color: 'text-status-closed' },
])

const handleLogout = () => {
  logout()
  router.push('/')
}

onMounted(() => {
  const ticketStats = getTicketStats()
  stats.value = [
    { label: 'Total Tickets', value: ticketStats.total, color: 'text-primary' },
    { label: 'Open', value: ticketStats.open, color: 'text-status-open' },
    {
      label: 'In Progress',
      value: ticketStats.inProgress,
      color: 'text-status-in-progress',
    },
    { label: 'Closed', value: ticketStats.closed, color: 'text-status-closed' },
  ]
})
</script>
