<template>
  <div class="min-h-screen bg-background">
    <!-- Navigation -->
    <nav class="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
          <div class="text-2xl font-bold text-primary">TicketFlow</div>

          <!-- Desktop Menu -->
          <div class="hidden md:flex items-center gap-4">
            <RouterLink
              v-if="authUser"
              to="/dashboard"
              class="text-foreground hover:text-primary transition"
            >
              Dashboard
            </RouterLink>
            <template v-else>
              <RouterLink
                to="/auth/login"
                class="text-foreground hover:text-primary transition"
              >
                Login
              </RouterLink>
              <RouterLink
                to="/auth/signup"
                class="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition"
              >
                Get Started
              </RouterLink>
            </template>
          </div>

          <!-- Mobile Menu Button -->
          <button
            class="md:hidden"
            @click="isMenuOpen = !isMenuOpen"
            aria-label="Toggle menu"
          >
            <Menu v-if="!isMenuOpen" class="w-6 h-6" />
            <X v-else class="w-6 h-6" />
          </button>
        </div>

        <!-- Mobile Menu -->
        <div v-if="isMenuOpen" class="md:hidden pb-4 space-y-2">
          <RouterLink
            v-if="authUser"
            to="/dashboard"
            class="block px-4 py-2 text-foreground hover:bg-secondary rounded-lg"
            @click="isMenuOpen = false"
          >
            Dashboard
          </RouterLink>
          <template v-else>
            <RouterLink
              to="/auth/login"
              class="block px-4 py-2 text-foreground hover:bg-secondary rounded-lg"
              @click="isMenuOpen = false"
            >
              Login
            </RouterLink>
            <RouterLink
              to="/auth/signup"
              class="block px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              @click="isMenuOpen = false"
            >
              Get Started
            </RouterLink>
          </template>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <section class="relative py-20 px-4 sm:px-6 lg:px-8">
      <div class="max-w-4xl mx-auto text-center">
        <h1 class="text-5xl md:text-6xl font-bold mb-6 text-balance">
          Manage Your Tickets Effortlessly
        </h1>
        <p class="text-xl text-muted-foreground mb-8 text-balance">
          TicketFlow is a modern ticket management system designed to streamline
          your workflow and boost productivity.
        </p>

        <div class="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <RouterLink
            v-if="authUser"
            to="/dashboard"
            class="px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition font-medium"
          >
            Dashboard
          </RouterLink>
          <template v-else>
            <RouterLink
              to="/auth/login"
              class="px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition font-medium"
            >
              Login
            </RouterLink>
            <RouterLink
              to="/auth/signup"
              class="px-8 py-3 border border-primary text-primary rounded-lg hover:bg-primary/10 transition font-medium"
            >
              Get Started
            </RouterLink>
          </template>
        </div>

        <!-- Decorative circle -->
        <div
          class="circle-decoration circle-lg absolute top-20 right-10 bg-primary/5 -z-10"
        ></div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/30">
      <div class="max-w-6xl mx-auto">
        <h2 class="text-4xl font-bold text-center mb-12">
          Why Choose TicketFlow?
        </h2>

        <div class="grid md:grid-cols-3 gap-8">
          <div
            v-for="feature in features"
            :key="feature.title"
            class="p-6 bg-card rounded-lg border border-border"
          >
            <div class="text-3xl mb-4">{{ feature.icon }}</div>
            <h3 class="text-xl font-semibold mb-2">{{ feature.title }}</h3>
            <p class="text-muted-foreground">{{ feature.description }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 px-4 sm:px-6 lg:px-8">
      <div class="max-w-4xl mx-auto text-center">
        <h2 class="text-4xl font-bold mb-6">Ready to Get Started?</h2>
        <p class="text-xl text-muted-foreground mb-8">
          Join thousands of teams using TicketFlow to manage their tickets
          efficiently.
        </p>
        <RouterLink
          to="/auth/signup"
          class="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition font-medium"
        >
          Start Free Today
        </RouterLink>
      </div>
    </section>

    <!-- Footer -->
    <footer class="bg-secondary/50 border-t border-border py-12 px-4 sm:px-6 lg:px-8">
      <div class="max-w-6xl mx-auto">
        <div class="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 class="font-bold text-lg mb-2">TicketFlow</h3>
            <p class="text-muted-foreground">
              Modern ticket management for teams
            </p>
          </div>
          <div>
            <h4 class="font-semibold mb-4">Product</h4>
            <ul class="space-y-2 text-muted-foreground">
              <li><a href="#" class="hover:text-foreground">Features</a></li>
              <li><a href="#" class="hover:text-foreground">Pricing</a></li>
            </ul>
          </div>
          <div>
            <h4 class="font-semibold mb-4">Legal</h4>
            <ul class="space-y-2 text-muted-foreground">
              <li><a href="#" class="hover:text-foreground">Privacy</a></li>
              <li><a href="#" class="hover:text-foreground">Terms</a></li>
            </ul>
          </div>
        </div>
        <div class="border-t border-border pt-8 text-center text-muted-foreground">
          &copy; 2025 TicketFlow. All rights reserved.
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { Menu, X } from 'lucide-vue-next'
import { authUser } from '@/lib/auth'

const isMenuOpen = ref(false)

const features = [
  {
    title: 'Easy to Use',
    description: 'Intuitive interface designed for teams of all sizes',
    icon: '✓',
  },
  {
    title: 'Real-time Updates',
    description: 'Stay synchronized with instant ticket status changes',
    icon: '⚡',
  },
  {
    title: 'Secure & Reliable',
    description: 'Your data is protected with industry-standard security',
    icon: '🔒',
  },
]
</script>
