<template>
  <div class="min-h-screen bg-background flex items-center justify-center px-4">
    <div class="w-full max-w-md">
      <div class="bg-card rounded-lg border border-border p-8">
        <h1 class="text-3xl font-bold mb-2">Welcome Back</h1>
        <p class="text-muted-foreground mb-6">
          Sign in to your TicketFlow account
        </p>

        <div v-if="errorMsg" class="mb-4 p-4 bg-destructive/10 text-destructive rounded-lg">
          {{ errorMsg }}
        </div>

        <form @submit.prevent="onSubmit" class="space-y-4">
          <div>
            <label class="block text-sm font-medium mb-2">Email</label>
            <input
              v-model="email"
              type="email"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="you@example.com"
            />
            <p v-if="emailError" class="text-destructive text-sm mt-1">
              {{ emailError }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium mb-2">Password</label>
            <input
              v-model="password"
              type="password"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="••••••••"
            />
            <p v-if="passwordError" class="text-destructive text-sm mt-1">
              {{ passwordError }}
            </p>
          </div>

          <button
            type="submit"
            :disabled="isSubmitting"
            class="w-full py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition disabled:opacity-50 font-medium flex items-center justify-center gap-2"
          >
            <Loader2 v-if="isSubmitting" class="w-4 h-4 animate-spin" />
            {{ isSubmitting ? 'Signing in...' : 'Sign In' }}
          </button>
        </form>

        <p class="text-center mt-6 text-muted-foreground">
          Don't have an account?
          <RouterLink to="/auth/signup" class="text-primary hover:underline">
            Sign up
          </RouterLink>
        </p>

        <div class="mt-8 p-4 bg-secondary/50 rounded-lg">
          <p class="font-semibold mb-2">Demo Credentials:</p>
          <p class="text-sm text-muted-foreground">
            Email: <span class="font-mono">test@example.com</span>
          </p>
          <p class="text-sm text-muted-foreground">
            Password: <span class="font-mono">password123</span>
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { Loader2 } from 'lucide-vue-next'
import { login } from '@/lib/auth'
import { toast } from 'sonner-vue'

const router = useRouter()

const email = ref('')
const password = ref('')
const errorMsg = ref<string | null>(null)
const isSubmitting = ref(false)
const emailError = ref('')
const passwordError = ref('')

const validateForm = () => {
  emailError.value = ''
  passwordError.value = ''

  if (!email.value) {
    emailError.value = 'Email is required'
  } else if (!email.value.includes('@')) {
    emailError.value = 'Please enter a valid email'
  }

  if (!password.value) {
    passwordError.value = 'Password is required'
  }

  return !emailError.value && !passwordError.value
}

const onSubmit = async () => {
  if (!validateForm()) return

  isSubmitting.value = true
  try {
    await new Promise((resolve) => setTimeout(resolve, 2000))
    await login(email.value, password.value)
    toast.success('Login successful!')
    router.push('/dashboard')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Login failed'
    errorMsg.value = message
    toast.error(message)
  } finally {
    isSubmitting.value = false
  }
}
</script>
