<template>
  <div class="min-h-screen bg-background flex items-center justify-center px-4">
    <div class="w-full max-w-md">
      <div class="bg-card rounded-lg border border-border p-8">
        <h1 class="text-3xl font-bold mb-2">Create Account</h1>
        <p class="text-muted-foreground mb-6">
          Join TicketFlow and start managing tickets
        </p>

        <div v-if="errorMsg" class="mb-4 p-4 bg-destructive/10 text-destructive rounded-lg">
          {{ errorMsg }}
        </div>

        <form @submit.prevent="onSubmit" class="space-y-4">
          <div>
            <label class="block text-sm font-medium mb-2">Full Name</label>
            <input
              v-model="name"
              type="text"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="John Doe"
            />
            <p v-if="nameError" class="text-destructive text-sm mt-1">
              {{ nameError }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium mb-2">Email</label>
            <input
              v-model="email"
              type="email"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="you@example.com"
            />
            <p v-if="emailError" class="text-destructive text-sm mt-1">
              {{ emailError }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium mb-2">Password</label>
            <input
              v-model="password"
              type="password"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="••••••••"
            />
            <p v-if="passwordError" class="text-destructive text-sm mt-1">
              {{ passwordError }}
            </p>
          </div>

          <button
            type="submit"
            :disabled="isSubmitting"
            class="w-full py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition disabled:opacity-50 font-medium flex items-center justify-center gap-2"
          >
            <Loader2 v-if="isSubmitting" class="w-4 h-4 animate-spin" />
            {{ isSubmitting ? 'Creating account...' : 'Create Account' }}
          </button>
        </form>

        <p class="text-center mt-6 text-muted-foreground">
          Already have an account?
          <RouterLink to="/auth/login" class="text-primary hover:underline">
            Sign in
          </RouterLink>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { Loader2 } from 'lucide-vue-next'
import { signup } from '@/lib/auth'
import { toast } from 'sonner-vue'

const router = useRouter()

const name = ref('')
const email = ref('')
const password = ref('')
const errorMsg = ref<string | null>(null)
const isSubmitting = ref(false)
const nameError = ref('')
const emailError = ref('')
const passwordError = ref('')

const validateForm = () => {
  nameError.value = ''
  emailError.value = ''
  passwordError.value = ''

  if (!name.value) {
    nameError.value = 'Full name is required'
  } else if (name.value.length < 2) {
    nameError.value = 'Full name must be at least 2 characters'
  }

  if (!email.value) {
    emailError.value = 'Email is required'
  } else if (!email.value.includes('@')) {
    emailError.value = 'Please enter a valid email address'
  }

  if (!password.value) {
    passwordError.value = 'Password is required'
  } else if (password.value.length < 6) {
    passwordError.value = 'Password must be at least 6 characters long'
  }

  return !nameError.value && !emailError.value && !passwordError.value
}

const onSubmit = async () => {
  if (!validateForm()) return

  isSubmitting.value = true
  try {
    await new Promise((resolve) => setTimeout(resolve, 2000))
    await signup(email.value, password.value, name.value)
    toast.success('Account created successfully!')
    router.push('/auth/login')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Signup failed'
    errorMsg.value = message
    toast.error(message)
  } finally {
    isSubmitting.value = false
  }
}
</script>
