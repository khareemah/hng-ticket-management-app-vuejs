<template>
  <div class="min-h-screen bg-background">
    <!-- Header -->
    <header class="bg-card border-b border-border sticky top-0 z-40">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="flex justify-between items-center">
          <h1 class="text-3xl font-bold">Create Ticket</h1>

          <!-- Desktop Buttons -->
          <div class="hidden md:flex gap-3">
            <RouterLink
              to="/tickets"
              class="px-4 py-2 border border-border rounded-lg hover:bg-secondary transition"
            >
              Back
            </RouterLink>
            <button
              @click="handleLogout"
              class="px-4 py-2 border border-border rounded-lg hover:bg-secondary transition"
            >
              Logout
            </button>
          </div>

          <!-- Mobile Menu Button -->
          <button
            class="md:hidden"
            @click="isMenuOpen = !isMenuOpen"
            aria-label="Toggle menu"
          >
            <Menu v-if="!isMenuOpen" class="w-6 h-6" />
            <X v-else class="w-6 h-6" />
          </button>
        </div>

        <!-- Mobile Menu -->
        <div v-if="isMenuOpen" class="md:hidden mt-4 space-y-2">
          <RouterLink
            to="/tickets"
            class="block px-4 py-2 border border-border rounded-lg hover:bg-secondary transition text-center"
          >
            Back
          </RouterLink>
          <button
            @click="handleLogout"
            class="w-full px-4 py-2 border border-border rounded-lg hover:bg-secondary transition"
          >
            Logout
          </button>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div class="bg-card rounded-lg border border-border p-8">
        <form @submit.prevent="onSubmit" class="space-y-6">
          <!-- Title -->
          <div>
            <label class="block text-sm font-medium mb-2">Title *</label>
            <input
              v-model="title"
              type="text"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="Enter ticket title"
            />
            <p v-if="titleError" class="text-destructive text-sm mt-1">
              {{ titleError }}
            </p>
          </div>

          <!-- Description -->
          <div>
            <label class="block text-sm font-medium mb-2">Description</label>
            <textarea
              v-model="description"
              class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring min-h-32"
              placeholder="Enter ticket description"
            ></textarea>
            <p v-if="descriptionError" class="text-destructive text-sm mt-1">
              {{ descriptionError }}
            </p>
          </div>

          <!-- Status & Priority -->
          <div class="grid md:grid-cols-2 gap-6">
            <!-- Status -->
            <div>
              <label class="block text-sm font-medium mb-2">Status</label>
              <select
                v-model="status"
                class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="closed">Closed</option>
              </select>
              <p v-if="statusError" class="text-destructive text-sm mt-1">
                {{ statusError }}
              </p>
            </div>

            <!-- Priority -->
            <div>
              <label class="block text-sm font-medium mb-2">Priority</label>
              <select
                v-model="priority"
                class="w-full px-4 py-2 border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
              <p v-if="priorityError" class="text-destructive text-sm mt-1">
                {{ priorityError }}
              </p>
            </div>
          </div>

          <!-- Buttons -->
          <div class="flex gap-4">
            <button
              type="submit"
              :disabled="isSubmitting"
              class="flex-1 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition disabled:opacity-50 font-medium flex items-center justify-center gap-2"
            >
              <Loader2 v-if="isSubmitting" class="w-4 h-4 animate-spin" />
              {{ isSubmitting ? 'Creating...' : 'Create Ticket' }}
            </button>
            <RouterLink
              to="/tickets"
              class="flex-1 py-2 border border-border rounded-lg hover:bg-secondary transition text-center font-medium"
            >
              Cancel
            </RouterLink>
          </div>
        </form>
      </div>
    </main>

    <!-- Footer -->
    <footer class="bg-secondary/50 border-t border-border py-8 px-4 sm:px-6 lg:px-8 mt-12">
      <div class="max-w-7xl mx-auto text-center text-muted-foreground">
        &copy; 2025 TicketFlow. All rights reserved.
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { Menu, X, Loader2 } from 'lucide-vue-next'
import { logout } from '@/lib/auth'
import { createTicket } from '@/lib/ticket-store'
import { toast } from 'sonner-vue'

const router = useRouter()

const title = ref('')
const description = ref('')
const status = ref<'open' | 'in_progress' | 'closed'>('open')
const priority = ref<'low' | 'medium' | 'high'>('low')
const isSubmitting = ref(false)
const isMenuOpen = ref(false)

const titleError = ref('')
const descriptionError = ref('')
const statusError = ref('')
const priorityError = ref('')

const validateForm = () => {
  titleError.value = ''
  descriptionError.value = ''
  statusError.value = ''
  priorityError.value = ''

  if (!title.value) {
    titleError.value = 'Title is required'
  } else if (title.value.length < 3) {
    titleError.value = 'Title must be at least 3 characters long'
  } else if (title.value.length > 100) {
    titleError.value = 'Title must not exceed 100 characters'
  }

  if (!description.value) {
    descriptionError.value = 'Description is required'
  } else if (description.value.length < 3) {
    descriptionError.value = 'Description must be at least 3 characters long'
  } else if (description.value.length > 1000) {
    descriptionError.value = 'Description too long'
  }

  return !titleError.value && !descriptionError.value
}

const onSubmit = async () => {
  if (!validateForm()) return

  isSubmitting.value = true
  try {
    await new Promise((resolve) => setTimeout(resolve, 2000))
    createTicket({
      title: title.value,
      description: description.value,
      status: status.value,
      priority: priority.value,
    })
    toast.success('Ticket created successfully!')
    router.push('/tickets')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create ticket'
    toast.error(message)
  } finally {
    isSubmitting.value = false
  }
}

const handleLogout = () => {
  logout()
  router.push('/')
}
</script>
